/* ==========================
   ADMIN REGISTER
========================== */

async function registerAdmin(){

    const fullName =
    document.getElementById(
        "fullName"
    ).value;

    const email =
    document.getElementById(
        "registerEmail"
    ).value;

    const password =
    document.getElementById(
        "registerPassword"
    ).value;

    const response =
    await fetch(
        "/adminRegister",
        {
            method:"POST",

            headers:{
                "Content-Type":
                "application/json"
            },

            body:JSON.stringify({

                fullName,
                email,
                password

            })

        }
    );

    const result =
    await response.json();

    alert(result.message);

}

/* ==========================
   ADMIN LOGIN
========================== */

async function adminLogin(){

    const email =
    document.getElementById(
        "loginEmail"
    ).value;

    const password =
    document.getElementById(
        "loginPassword"
    ).value;

    const response =
    await fetch(
        "/adminLogin",
        {
            method:"POST",

            headers:{
                "Content-Type":
                "application/json"
            },

            body:JSON.stringify({

                email,
                password

            })

        }
    );

    const result =
    await response.json();

    if(result.success){

        window.location.href =
        "adminDashboard.html";

    }else{

        alert(result.message);

    }

}

/* ==========================
   DASHBOARD STATS
========================== */

async function loadDashboard(){

    const response =
    await fetch("/adminStats");

    const data =
    await response.json();

    if(document.getElementById("employeeCount"))
        document.getElementById("employeeCount").innerText =
        data.employees;

    if(document.getElementById("leaveCount"))
        document.getElementById("leaveCount").innerText =
        data.requests;

    if(document.getElementById("approvedCount"))
        document.getElementById("approvedCount").innerText =
        data.approved;

    if(document.getElementById("pendingCount"))
        document.getElementById("pendingCount").innerText =
        data.pending;

    const chartCanvas =
    document.getElementById(
        "adminChart"
    );

    if(chartCanvas){

        new Chart(chartCanvas,{

            type:"doughnut",

            data:{

                labels:[
                    "Approved",
                    "Pending",
                    "Rejected"
                ],

                datasets:[{

                    data:[
                        data.approved,
                        data.pending,
                        data.rejected
                    ],

                    backgroundColor:[
                        "#22c55e",
                        "#f59e0b",
                        "#ef4444"
                    ]

                }]

            }

        });

    }

}

/* ==========================
   LOAD EMPLOYEES
========================== */

async function loadEmployees(){

    const response =
    await fetch("/allEmployees");

    const employees =
    await response.json();

    let table =
    document.getElementById(
        "employeeTable"
    );

    table.innerHTML = "";

    employees.forEach(emp=>{

        table.innerHTML += `

        <tr>

            <td>${emp.employeeId}</td>

            <td>${emp.fullName}</td>

            <td>${emp.email}</td>

        </tr>

        `;

    });

}

/* ==========================
   LOAD LEAVES
========================== */

async function loadLeaves(){

    const response =
    await fetch("/allLeaves");

    const leaves =
    await response.json();

    const table =
    document.getElementById(
        "leaveTable"
    );

    if(!table) return;

    table.innerHTML = "";

    leaves.forEach(leave=>{

        table.innerHTML += `

        <tr>

            <td>${leave.fullName}</td>

            <td>${leave.leaveType}</td>

            <td>${leave.fromDate.split("T")[0]}</td>

            <td>${leave.toDate.split("T")[0]}</td>

            <td>${leave.status}</td>

            <td>

    <button
    class="approve-btn"
    onclick="approveLeave('${leave._id}')">
    Approve
    </button>

    <button
    class="reject-btn"
    onclick="rejectLeave('${leave._id}')">
    Reject
    </button>

</td>

        </tr>

        `;

    });

}

/* ==========================
   APPROVE LEAVE
========================== */

async function approveLeave(id){

    await fetch(
        "/approveLeave/" + id,
        {
            method:"PUT"
        }
    );

    location.reload();

}

/* ==========================
   REJECT LEAVE
========================== */

async function rejectLeave(id){

    await fetch(
        "/rejectLeave/" + id,
        {
            method:"PUT"
        }
    );

    location.reload();

}

/* ==========================
   LOGOUT
========================== */

function logout(){

    localStorage.clear();

    window.location.href =
    "adminLogin.html";

}

/* ==========================
   AUTO LOAD
========================== */

if(window.location.pathname.includes("adminDashboard")){

loadDashboard();
loadLeaves();
loadEmployees();

}