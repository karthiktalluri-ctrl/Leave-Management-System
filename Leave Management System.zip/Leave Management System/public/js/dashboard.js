const user =
JSON.parse(
localStorage.getItem(
"employee"
));

if(!user){

    window.location.href =
    "index.html";

}

document.getElementById(
"name"
).innerHTML =
"Welcome " +
user.fullName;

document.getElementById(
"employeeId"
).innerHTML =
"Employee ID : " +
user.employeeId;

document.getElementById(
"email"
).innerHTML =
"Email : " +
user.email;

async function loadStats(){

    try{

        const response =
        await fetch(
        `/leaveStats/${user.employeeId}`
        );

        const data =
        await response.json();

        document.getElementById(
        "leaveBalance"
        ).innerHTML =
        data.leaveBalance;

        document.getElementById(
        "totalLeaves"
        ).innerHTML =
        data.totalLeaves;

        document.getElementById(
        "approvedLeaves"
        ).innerHTML =
        data.approvedLeaves;

        document.getElementById(
        "pendingLeaves"
        ).innerHTML =
        data.pendingLeaves;

        const ctx =
        document.getElementById(
        "leaveChart"
        );

        new Chart(ctx,{

            type:"doughnut",

            data:{

                labels:[
                    "Approved",
                    "Pending",
                    "Rejected"
                ],

                datasets:[{

                    data:[
                        data.approvedLeaves,
                        data.pendingLeaves,
                        data.rejectedLeaves
                    ],

                    backgroundColor:[
                        "#22c55e",
                        "#f59e0b",
                        "#ef4444"
                    ]

                }]

            }

        });

    }catch(error){

        console.log(error);

    }

}

function logout(){

    localStorage.clear();

    window.location.href =
    "index.html";

}

loadStats();