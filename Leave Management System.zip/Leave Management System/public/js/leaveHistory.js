let user =
JSON.parse(
localStorage.getItem("employee")
);

loadLeaves();

async function loadLeaves(){

    const response =
    await fetch(
        `/myLeaves/${user.employeeId}`
    );

    const leaves =
    await response.json();

    let table = "";

    leaves.forEach(leave => {

        table += `

        <tr>

            <td>${leave.leaveType}</td>

            <td>${leave.fromDate}</td>

            <td>${leave.toDate}</td>

            <td>${leave.status}</td>

        </tr>

        `;

    });

    document.getElementById(
        "leaveTable"
    ).innerHTML = table;
}
