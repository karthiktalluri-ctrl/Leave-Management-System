async function applyLeave() {

    let user =
    JSON.parse(
        localStorage.getItem("employee")
    );

    const response =
    await fetch("/applyLeave",{

        method:"POST",

        headers:{
            "Content-Type":
            "application/json"
        },

        body:JSON.stringify({

            employeeId:
            user.employeeId,

            fullName:
            user.fullName,

            leaveType:
            document.getElementById("leaveType").value,

            fromDate:
            document.getElementById("fromDate").value,

            toDate:
            document.getElementById("toDate").value,

            reason:
            document.getElementById("reason").value

        })

    });

    const result =
    await response.json();

    if(result.success){

        window.location.href =
        "leaveSuccess.html";

    }else{

        alert(result.message);

    }

}