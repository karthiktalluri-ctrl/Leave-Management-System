async function register() {

    const employeeId =
    document.getElementById(
    "employeeId"
    ).value;

    const fullName =
    document.getElementById(
    "fullName"
    ).value;

    const email =
    document.getElementById(
    "email"
    ).value;

    const password =
    document.getElementById(
    "password"
    ).value;

    const confirmPassword =
    document.getElementById(
    "confirmPassword"
    ).value;

    if(
        employeeId === "" ||
        fullName === "" ||
        email === "" ||
        password === ""
    ){
        alert(
        "Please fill all fields"
        );
        return;
    }

    if(
        password !==
        confirmPassword
    ){
        alert(
        "Passwords do not match"
        );
        return;
    }

    try{

        const response =
        await fetch(
        "/register",
        {
            method:"POST",

            headers:{
                "Content-Type":
                "application/json"
            },

            body:JSON.stringify({

                employeeId,
                fullName,
                email,
                password

            })

        });

        const result =
        await response.json();

        alert(
        result.message
        );

    }catch(error){

        console.log(error);

        alert(
        "Registration Failed"
        );

    }

}

async function login(){

    const email =
    document.getElementById(
    "loginEmail"
    ).value;

    const password =
    document.getElementById(
    "loginPassword"
    ).value;

    if(
        email === "" ||
        password === ""
    ){
        alert(
        "Enter Email and Password"
        );
        return;
    }

    try{

        const response =
        await fetch(
        "/login",
        {
            method:"POST",

            headers:{
                "Content-Type":
                "application/json"
            },

            body:JSON.stringify({

                email,
                password

            })

        });

        const result =
        await response.json();

        if(result.success){

            localStorage.setItem(

                "employee",

                JSON.stringify(
                result.user
                )

            );

            window.location.href =
            "dashboard.html";

        }else{

            alert(
            result.message
            );

        }

    }catch(error){

        console.log(error);

        alert(
        "Login Failed"
        );

    }

}