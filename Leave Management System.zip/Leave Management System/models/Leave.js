const mongoose = require("mongoose");

const LeaveSchema = new mongoose.Schema({

    employeeId: {
        type: String,
        required: true
    },

    fullName: {
        type: String,
        required: true
    },

    leaveType: {
        type: String,
        required: true
    },

    fromDate: {
        type: Date,
        required: true
    },

    toDate: {
        type: Date,
        required: true
    },

    reason: {
        type: String,
        required: true
    },

    status: {
        type: String,
        default: "Pending"
    },

    appliedOn: {
        type: Date,
        default: Date.now
    }

});

module.exports = mongoose.model(
    "Leave",
    LeaveSchema
);